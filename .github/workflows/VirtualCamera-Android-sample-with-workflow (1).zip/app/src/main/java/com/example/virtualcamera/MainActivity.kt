package com.example.virtualcamera

import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem

class MainActivity : AppCompatActivity() {

    private lateinit var textureView: TextureView
    private lateinit var btnChoose: Button
    private lateinit var btnPlayPause: Button
    private lateinit var btnMirror: Button

    private var player: ExoPlayer? = null
    private var isPlaying = false
    private var isMirrored = false

    private val pickMedia = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { playUri(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textureView = findViewById(R.id.previewTexture)
        btnChoose = findViewById(R.id.btnChoose)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnMirror = findViewById(R.id.btnMirror)

        btnChoose.setOnClickListener {
            // allow video selection; to allow images too, change to "*/*"
            pickMedia.launch("video/*")
        }

        btnPlayPause.setOnClickListener {
            if (isPlaying) pause() else resume()
        }

        btnMirror.setOnClickListener {
            isMirrored = !isMirrored
            applyMirror()
        }
    }

    private fun playUri(uri: Uri) {
        releasePlayer()
        player = ExoPlayer.Builder(this).build().also { exo ->
            val mediaItem = MediaItem.fromUri(uri)
            exo.setMediaItem(mediaItem)
            exo.repeatMode = ExoPlayer.REPEAT_MODE_ONE
            // use TextureView as video surface
            val surface = textureView.surfaceTexture?.let { st ->
                Surface(st)
            }
            surface?.let { exo.setVideoSurface(it) }
            exo.prepare()
            exo.playWhenReady = true
            isPlaying = true
            btnPlayPause.text = "Pause"
        }
    }

    private fun pause() {
        player?.playWhenReady = false
        isPlaying = false
        btnPlayPause.text = "Play"
    }

    private fun resume() {
        player?.playWhenReady = true
        isPlaying = true
        btnPlayPause.text = "Pause"
    }

    private fun applyMirror() {
        val matrix = Matrix()
        if (isMirrored) {
            matrix.setScale(-1f, 1f, textureView.width / 2f, textureView.height / 2f)
        } else {
            matrix.setScale(1f, 1f)
        }
        textureView.setTransform(matrix)
    }

    private fun releasePlayer() {
        player?.release()
        player = null
        isPlaying = false
        btnPlayPause.text = "Play"
    }

    override fun onPause() {
        super.onPause()
        pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
    }
}
